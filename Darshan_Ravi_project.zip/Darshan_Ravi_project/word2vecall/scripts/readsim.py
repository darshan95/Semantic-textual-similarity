import re
import sys
import os
import codecs
from gensim.models import word2vec
import logging



logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
model = word2vec.Word2Vec.load("model.model")
sen_dic_1={}
sen_dic_2={}

f=codecs.open(sys.argv[1])
data=f.readlines()
f.close()
sen_count=0
for i in data:
	i=i.strip().split()
	sen_count+=1
	sen_dic_1[sen_count]={}
	chunk_count=0
	for j in i:
		chunk_count+=1
		sen_dic_1[sen_count][chunk_count]=j

f=codecs.open(sys.argv[2])
data=f.readlines()
f.close()
sen_count=0
for i in data:
	i=i.strip().split()
	sen_count+=1
	sen_dic_2[sen_count]={}
	chunk_count=0
	for j in i:
		chunk_count+=1
		sen_dic_2[sen_count][chunk_count]=j

#for i in sen_dic_1:
#	print i,sen_dic_1[i]





f=codecs.open(sys.argv[3])
data=f.readlines()
f.close()
chunk_dic_1={}
chunk_dic_2={}

sen_count=0
for i in data:
	i=i.strip()
	sen_count+=1
	i1=i.split('[')
	chunk_count=-1
	chunk_dic_1[sen_count]={}
	chunk_dic_1[sen_count]['s']=i
	for j in i1:
		chunk_count+=1
		j1=j.replace(']','').strip()
		if j1!='':
			chunk_dic_1[sen_count][chunk_count]=j1
f=codecs.open(sys.argv[4])
data=f.readlines()
f.close()
sen_count=0
for i in data:
	i=i.strip()
	sen_count+=1
	i1=i.split('[')
	chunk_count=-1
	chunk_dic_2[sen_count]={}
	chunk_dic_2[sen_count]['s']=i
	for j in i1:
		chunk_count+=1
		j1=j.replace(']','').strip()
		if j1!='':
			chunk_dic_2[sen_count][chunk_count]=j1


#for i in chunk_dic_1:
#	print i,'\n\t 1 ===>   ',chunk_dic_1[i]
#	break
#	print i,'\n\t 2 ===>   ',chunk_dic_2[i]





f=codecs.open(sys.argv[5])
data=f.readlines()
f.close()
alflag=False
relDic={}
senpairid=1
for i in data:
	i=i.strip()

	if re.search('<\/alignment>',i,re.I|re.M):
		alflag=False
		#break
	if alflag:
		gzcount+=1
		part=i.split('//')
		localcount=0
		for j in part:
			localcount+=1
			if localcount==1:
				j1=j.split('<==>')
				j1[0]=j1[0].strip()
				j1[1]=j1[1].strip()
				fj1=j1[0].split(' ')
				sj1=j1[1].split(' ')
				if gzcount==1:
					relDic[senpairid]['1']={}
					relDic[senpairid]['2']={}
				
				relDic[senpairid]['1'][gzcount]={}
				relDic[senpairid]['2'][gzcount]={}
				relDic[senpairid]['1'][gzcount]['mapping']=[]
				relDic[senpairid]['2'][gzcount]['mapping']=[]
				for g in fj1:
					relDic[senpairid]['1'][gzcount]['mapping'].append(g)
				for g in sj1:	
					relDic[senpairid]['2'][gzcount]['mapping'].append(g)
			elif localcount==2:
				relDic[senpairid]['1'][gzcount]['rel']=j.strip()
				relDic[senpairid]['2'][gzcount]['rel']=j.strip()
			elif localcount==3:
				relDic[senpairid]['1'][gzcount]['score']=j.strip()
				relDic[senpairid]['2'][gzcount]['score']=j.strip()
			else:
				das=j
			
		
	if re.search('<sentence id=.*',i,re.M|re.I):
		senre=re.search('<sentence id=("|\')([0-9]+)("|\').*',i,re.M|re.I)
		senpairid=senre.group(2)
		relDic[senpairid]={}
	if re.search('<alignment>',i,re.I|re.M):
		alflag=True 
		gzcount=0
	
#print relDic
#print sen_dic_1
"""
for i in relDic:
	print '\n\n\n New===>'
	for k in relDic[i]['1']:
		print '==================>',k
		for l in relDic[i]['1'][k]['mapping']:
			if l=='0':
				print l,'===>','NULL'
				#continue
			else:
				#if len(sen_dic_1[int(i)][int(l)])>2:
					print l,'===>',#sen_dic_1[int(i)][int(l)],model[str(sen_dic_1[int(i)][int(l)]).strip()]
		print '<================='
		for l in relDic[i]['2'][k]['mapping']:
			if l=='0':
				print l,'===>','NULL'
				#continue
			else:
				#if len(sen_dic_2[int(i)][int(l)])>2:
					print l,'===>',#sen_dic_2[int(i)][int(l)],model[str(sen_dic_2[int(i)][int(l)]).strip()]

"""
f = open("input1.txt",'w')
f.close()
f = open("input2.txt",'w')
f.close()
#f = open("mapping.txt",'w')
#f.close()
mapping = []

for i in range(1,len(relDic.keys())+1):
    i = str(i);
    j = 0;
    for k in range(1,len(relDic[i]['1'])+1):
        j += 1;
        o = sys.stdout;
        f = open("input1.txt",'a')
        sys.stdout = f;
        vec = []
        for index in range(0,200):
            vec.append(0.0)
        for l in relDic[i]['1'][k]['mapping']:
            if l=='0':
                ind = 0;
                
                for index in model['.']:
                    vec[ind] += index;
                    ind += 1
                  
                #print model['.']
            else:
                try:
                    #print "typr"
                    #print type(model)
                    #print model[str(sen_dic_1[int(i)][int(l)]).strip()]
                    ind = 0;
                    for index in model[str(sen_dic_1[int(i)][int(l)]).strip()]:
                        vec[ind] += index
                        ind += 1
                        #print type(index)
                        #print index
                except:
                    ind = 0;
                    for index in model['.']:
                        vec[ind] += index;
                        ind += 1
                    #print model['.']
        print vec 
        sys.stdout = o;
        f.close();
        #o = sys.stdout;
        #f = open("mapping.txt",'a')
        #sys.stdout = f;
  #      print j
#        print relDic[i]['1'][j]
 #       print relDic[i]['1'][j]['rel']       
        mapping.append(relDic[i]['1'][j]['rel'])
        #sys.stdout = o
        #f.close()
        o = sys.stdout;
        f = open("input2.txt",'a')
        sys.stdout = f;
        
        
        vec = []
        for index in range(0,200):
            vec.append(0.0)
	for l in relDic[i]['2'][k]['mapping']:
	    if l=='0':
                ind = 0;
                for index in model['.']:
                    vec[ind] += index
                    ind += 1
                #print model['.']
                #continue
            else:
                #if len(sen_dic_2[int(i)][int(l)])>2:
                try:
                    ind = 0;
                    for index in model[str(sen_dic_2[int(i)][int(l)]).strip()]:
                        vec[ind] += index
                        ind += 1
  
                    #print model[str(sen_dic_2[int(i)][int(l)]).strip()]
                except:
                    ind = 0;
                    for index in model['.']:
                        vec[ind] += index
                        ind += 1
 
                    #print model['.']

                #print l,'===>',#sen_dic_2[int(i)][int(l)],model[str(sen_dic_2[int(i)][int(l)]).strip()]
           #for l in relDic[i]['2'][k]['mapping']:
        print vec
        sys.stdout = o;
        f.close();

o = sys.stdout;
f = open("output.txt",'w')
sys.stdout = f;
cnt = 0;
a=[]
for i in mapping:
    if i not in a:
        a.append(i)
        print a.index(i) + 1
    else:
        print a.index(i) + 1
#mapping.append(relDic[i]['1'][k]['rel'])
sys.stdout = o
f.close()

"""
for line in open("mapping.txt",'r'):
    if line not in a:
        a.append(line)
print len(a)
print a
"""
