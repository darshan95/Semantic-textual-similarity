import gensim,logging,sys
import os
class MySentences(object):
	def __init__(self, dirname):
	    self.dirname = dirname

	def __iter__(self):
	    for fname in os.listdir(self.dirname):
	        for line in open(os.path.join(self.dirname, fname)):
	             yield line.split()

sentences=MySentences(sys.argv[1])
model = gensim.models.Word2Vec(sentences, min_count=10, size=200, workers=4)
model.save('model.model')
