import re
import sys
import os
import codecs

f=codecs.open(sys.argv[1])
data=f.readlines()
chunk_dic={}


sen_count=0
for i in data:
	i=i.strip()
	sen_count+=1
	i1=i.split('[')
	chunk_count=-1
	chunk_dic[sen_count]={}
	chunk_dic[sen_count]['s']=i
	for j in i1:
		chunk_count+=1
		j1=j.replace(']','').strip()
		if j1!='':
			chunk_dic[sen_count][chunk_count]=j1
for i in chunk_dic:
	print i,chunk_dic[i]
	
