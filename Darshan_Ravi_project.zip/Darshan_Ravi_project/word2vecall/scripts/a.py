f = open("mapping.txt",'r')
a=[]
for line in open("mapping.txt",'r'):
    if line not in a:
        a.append(line)
print len(a)
print a
