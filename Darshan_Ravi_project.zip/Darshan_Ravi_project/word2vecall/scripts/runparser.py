import os
from nltk.parse import stanford

os.environ['STANFORD_PARSER'] = '../../tools/stanford-parser-full-2014-10-31/stanford-parser.jar'
os.environ['STANFORD_MODELS'] = '../../tools/stanford-parser-full-2014-10-31/stanford-parser-3.5.0-models.jar'

parser = stanford.StanfordParser(model_path="../../tools/stanford-parser-full-2014-10-31/englishPCFG.ser.gz")
sentences = parser.raw_parse_sents(("Hello, My name is Melroy.", "What is your name?"))
print sentences

# GUI
for sentence in sentences:
    sentence.draw()
