#
#	python fnn.py embeddings.en(1) embeddings.hn(2) train(3) tes(4)t model(5) dimensions(6) test_dist(7)
#
#
from pybrain.datasets            import ClassificationDataSet
from pybrain.datasets            import SupervisedDataSet
from pybrain.utilities           import percentError
from pybrain.tools.shortcuts     import buildNetwork
from pybrain.supervised.trainers import BackpropTrainer
from pybrain.optimization.optimizer import BlackBoxOptimizer
from pybrain.structure.modules   import SoftmaxLayer
from pybrain.structure import LinearLayer, SigmoidLayer,FullConnection, FeedForwardNetwork
import numpy,sys
import pickle
#from pylab import ion, ioff, figure, draw, contourf, clf, show, hold, plot
from scipy import diag, arange, meshgrid, where
from numpy.random import multivariate_normal
from gensim.models.word2vec import *
from scipy.spatial import distance

embeddings_eng = sys.argv[1]
embeddings_hin = sys.argv[2]
matrix1=[]
matrix2=[]
train = {line.split()[0].strip():line.split()[1].strip() for line in open(sys.argv[3])}
test = {line.split()[0].strip():line.split()[1].strip() for line in open(sys.argv[4])}
print '... Loading embeddings file'
model_eng = Word2Vec.load_word2vec_format(embeddings_eng, binary=False)
model_hin = Word2Vec.load_word2vec_format(embeddings_hin, binary=False)
dim=int(sys.argv[6])
DSTrain = SupervisedDataSet( dim, dim )
DSTest = SupervisedDataSet( dim, dim )
for eng,hin in train.items():
	try:
		eng_vector=model_eng[eng]
		hin_vector=model_hin[hin]
		a=eng_vector.tolist()
		b=hin_vector.tolist()
		DSTrain.appendLinked( a, b )
	except:
		continue
for eng,hin in test.items():
	try:
		eng_vector=model_eng[eng]
		hin_vector=model_hin[hin]
		a=eng_vector.tolist()
		b=hin_vector.tolist()
		DSTest.appendLinked( a, b )
	except:
		continue
print len(DSTrain)
print len(DSTrain)
tstdata_fake, trndata = DSTrain.splitWithProportion( 0 )
trndata_fake, tstdata = DSTest.splitWithProportion( 0 )
#trndata._convertToOneOfMany( )
#tstdata._convertToOneOfMany( )

print "Number of training patterns: ", len(trndata)
print "Input and output dimensions: ", trndata.indim, trndata.outdim
print "Number of testing patterns: ", len(tstdata)
print "Input and output dimensions: ", tstdata.indim, tstdata.outdim
#print "First sample (input, target, class):"
#print trndata['input'][0], trndata['target'][0]
#print type(trndata)
#exit(0)
'''
fnn = FeedForwardNetwork()
inLayer = LinearLayer(50)
hiddenLayer = SigmoidLayer(200)
outLayer = LinearLayer(50)
in_to_hidden = FullConnection(inLayer, hiddenLayer)
hidden_to_out = FullConnection(hiddenLayer, outLayer)
fnn.addConnection(in_to_hidden)
fnn.addConnection(hidden_to_out)
#fnn.sortModules()
'''
fnn = buildNetwork( trndata.indim, 400,400, trndata.outdim )
print '... layer Details'
print fnn['in']
print fnn['hidden0']
print fnn['hidden1']
print fnn['out']
trainer = BackpropTrainer( fnn, dataset=trndata, momentum=0.1, verbose=True, weightdecay=0.01)
#BlackBoxOptimizer(evaluator=minimize)
print '... Training starts'
for i in range(10):
	trainer.trainUntilConvergence(maxEpochs=20,validationProportion=0.25)
#	trainer.trainEpochs( 20 )

fileObject = open(sys.argv[5], 'w')
pickle.dump(fnn, fileObject)
fileObject.close()
print '... Model dumped'
#------------------------------------------------------------------------------------------------------------------------------
fileObject = open(sys.argv[5],'r')
file_dist = open(sys.argv[7],'w')
#file_dist_rev = open('dist_test_rev.txt','w')
#euclidean_file = open('euclidean_1.txt','w')

fnn = pickle.load(fileObject)
for i in range(len(tstdata)):	
	out1 = fnn.activate(tstdata['input'][i])
	dist= 1 - distance.cosine(out1.tolist(), tstdata['target'][i])
#	dist_rev =  distance.cosine(out1.tolist(), tstdata['target'][i])
#	euc =  distance.euclidean(out1.tolist(), tstdata['target'][i])
	file_dist.write(str(dist)+'\n')
#	file_dist_rev.write(str(dist_rev)+'\n')
#	euclidean_file.write(str(euc)+'\n')
exit(0)	

'''
for i in range(1):
	trainer.trainEpochs( 1 )
	trnresult = percentError( trainer.testOnClassData(),trndata['class'] )
	tstresult = percentError( trainer.testOnClassData(dataset=tstdata ), tstdata['class'] )
	print "epoch: %4d" % trainer.totalepochs,"  train error: %5.2f%%" % trnresult,"  test error: %5.2f%%" % tstresult
	out = fnn.activateOnDataset(griddata)
	out = out.argmax(axis=1)  # the highest output activation gives the class
	out = out.reshape(X.shape)
'''
#	figure(1)
#        ioff()  # interactive graphics off
#        clf()   # clear the plot
#        hold(True) # overplot on
#        for c in [0,1,2]:
#		here, _ = where(tstdata['class']==c)
#		plot(tstdata['input'][here,0],tstdata['input'][here,1],'o')
#	if out.max()!=out.min():  # safety check against flat field
#		contourf(X, Y, out)   # plot the contour
#	ion()   # interactive graphics on
#	draw()  #

