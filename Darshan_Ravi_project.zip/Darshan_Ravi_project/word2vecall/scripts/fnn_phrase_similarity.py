#
#	python fnn_phrase_similarity.py embeddings.en(1) embeddings.hn(2) combined(3) model(4) dimension(5) dist_write(6)
#
#
from pybrain.datasets            import ClassificationDataSet
from pybrain.datasets            import SupervisedDataSet
from pybrain.utilities           import percentError
from pybrain.tools.shortcuts     import buildNetwork
from pybrain.supervised.trainers import BackpropTrainer
from pybrain.optimization.optimizer import BlackBoxOptimizer
from pybrain.structure.modules   import SoftmaxLayer
from pybrain.structure import LinearLayer, SigmoidLayer,FullConnection, FeedForwardNetwork
import numpy,sys
import pickle
#from pylab import ion, ioff, figure, draw, contourf, clf, show, hold, plot
#from scipy import diag, arange, meshgrid, where
from gensim.models.word2vec import *
from scipy.spatial import distance

embeddings_eng = sys.argv[1]
embeddings_hin = sys.argv[2]
print '... Loading embeddings file'
model_eng = Word2Vec.load_word2vec_format(embeddings_eng, binary=False)
model_hin = Word2Vec.load_word2vec_format(embeddings_hin, binary=False)
combined = open(sys.argv[3],'r')
print '... Loading model'
model_file = open(sys.argv[4],'r')
model=pickle.load(model_file)
dim = int(sys.argv[5])
dist_write = open(sys.argv[6],'w')
print '... computing scores'
for line in combined:
	line = line.strip()
	[eng,hin] = line.split('\t')
	parts_1 = eng.split(' ')
	parts_2 = hin.split(' ')
	result_1 = numpy.zeros(shape=(1,dim))
	for key_1 in parts_1:
		try:
			old_1 = model_eng[key_1]
			
		except Exception,e:
			pass
		else:
			old_1 = old_1.tolist()
			new_matrix = numpy.matrix(model.activate(old_1))
#			new_matrix = old_1*weights
			result_1 = result_1+new_matrix
			#result_1 = result_1+old_1 
	result_2 = numpy.zeros(shape=(1,dim))
	print parts_2
	for key_2 in parts_2:
		try:
			old_2 = numpy.matrix(model_hin[key_2])
		except Exception,e:
			pass
		else:
#			old_2=old_2.tolist()
			result_2 = result_2+old_2
	print result_1
	print result_2
	dist = 1- distance.cosine(result_1.tolist()[0],result_2.tolist()[0])
	dist_write.write(str(dist)+'\n')
	exit(0)
		
'''
for eng,hin in train.items():
	try:
		eng_vector=model_eng[eng]
		hin_vector=model_hin[hin]
		a=eng_vector.tolist()
		b=hin_vector.tolist()
		DSTrain.appendLinked( a, b )
	except:
		continue
for eng,hin in test.items():
	try:
		eng_vector=model_eng[eng]
		hin_vector=model_hin[hin]
		a=eng_vector.tolist()
		b=hin_vector.tolist()
		DSTest.appendLinked( a, b )
	except:
		continue
fnn = buildNetwork( trndata.indim, 200,200, trndata.outdim )
print '... layer Details'
print fnn['hidden0']
print fnn['hidden1']
print fnn['in']
print fnn['out']
file_dist = open(sys.argv[7],'w')
#file_dist_rev = open('dist_test_rev.txt','w')
#euclidean_file = open('euclidean_1.txt','w')

fnn = pickle.load(fileObject)
for i in range(len(tstdata)):	
	out1 = fnn.activate(tstdata['input'][i])
	dist= 1 - distance.cosine(out1.tolist(), tstdata['target'][i])
#	dist_rev =  distance.cosine(out1.tolist(), tstdata['target'][i])
#	euc =  distance.euclidean(out1.tolist(), tstdata['target'][i])
	file_dist.write(str(dist)+'\n')
#	file_dist_rev.write(str(dist_rev)+'\n')
#	euclidean_file.write(str(euc)+'\n')
exit(0)	
'''
