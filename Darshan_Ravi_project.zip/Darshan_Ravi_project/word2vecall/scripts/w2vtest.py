from gensim.models import word2vec
import logging
import os
import sys


logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
model = word2vec.Word2Vec.load("text8.model")

#all_var=model.most_similar(positive=[sys.argv[1]], topn=100)
#for i in all_var:
#	print i

print model[sys.argv[1]]
#print model.doesnt_match("breakfast cereal dinner lunch".split())
#print model.similarity('woman', 'man')

