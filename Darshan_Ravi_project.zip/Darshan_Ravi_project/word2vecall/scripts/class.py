import numpy as np
import pybrain
from pybrain.datasets            import ClassificationDataSet
from pybrain.utilities           import percentError
from pybrain.tools.shortcuts     import buildNetwork
from pybrain.supervised.trainers import BackpropTrainer
from pybrain.structure.modules   import SoftmaxLayer
n=sum(1 for line in open('input1.txt'))
with open('input1.txt') as f1:	#opens the file input1
	content1=f1.readlines()
with open('input2.txt') as f2:  #opens the file input2
	content2=f2.readlines()
X=np.empty(400)
for i in range(n):
	line1=content1[i][1:-2].split(',')
	line1=[float(j) for j in line1]
	line2=content2[i][1:-2].split(',')
	line2=[float(j) for j in line2]
	line=line1+line2
	#print isinstance(line,list)
	X=np.vstack((X,line))
X=np.delete(X,0, 0)
f1.close()
f2.close()
with open('output.txt') as f3:
	content3=f3.readlines()
Y=np.empty(1)
for i in range(n):
	line3=int(content3[i])
	Y=np.vstack((Y,line3))
Y=np.delete(Y,0,0)
f3.close()
alldata = ClassificationDataSet(400,15,nb_classes=15)# 400 is the dimension 12 classes 
for i in range(n):
	alldata.addSample(X[i,:],[Y[i,:]])
tstdata, trndata = alldata.splitWithProportion(0.20) #training and testing data split
trndata._convertToOneOfMany( )
tstdata._convertToOneOfMany( )
fnn = buildNetwork( trndata.indim, 10, trndata.outdim, outclass=SoftmaxLayer )# 5 is the number of hidden units.Can be changed
trainer = BackpropTrainer( fnn, dataset=trndata, momentum=0.1, verbose=True, weightdecay=0.01)
for j in range(20): #number of iterations
	trainer.trainEpochs(5)
trnresult = percentError(trainer.testOnClassData(),trndata['class'] )
tstresult = percentError(trainer.testOnClassData(dataset=tstdata ), tstdata['class'] )
print "train"
print trnresult #prints the training percent error not accuracy
print "test"
print tstresult #printst the testing percent error not accuracy


